-- ============================================================
-- Hostel Management System - Database Schema
-- Run this file in MySQL to set up the database
-- ============================================================

CREATE DATABASE IF NOT EXISTS hostel_db;
USE hostel_db;

-- -------------------------------------------------------
-- Table: rooms
-- Stores all hostel rooms
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    floor INT NOT NULL,
    capacity INT NOT NULL DEFAULT 2,
    current_occupancy INT NOT NULL DEFAULT 0,
    room_type ENUM('single', 'double', 'triple') DEFAULT 'double',
    status ENUM('available', 'full', 'maintenance') DEFAULT 'available',
    monthly_fee DECIMAL(10,2) NOT NULL DEFAULT 5000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- -------------------------------------------------------
-- Table: admins
-- Stores admin login credentials
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- -------------------------------------------------------
-- Table: students
-- Stores student details (room_id is foreign key)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    roll_number VARCHAR(30) UNIQUE,
    course VARCHAR(100),
    year_of_study INT,
    room_id INT,
    join_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL
);

-- -------------------------------------------------------
-- Table: fees
-- Tracks fee payment status per student per month
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    month VARCHAR(20) NOT NULL,       -- e.g., "June 2025"
    year INT NOT NULL,
    status ENUM('paid', 'pending', 'overdue') DEFAULT 'pending',
    payment_date DATE,
    due_date DATE NOT NULL,
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- -------------------------------------------------------
-- Table: complaints
-- Students submit complaints; admin updates status
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('maintenance', 'food', 'security', 'cleanliness', 'other') DEFAULT 'other',
    status ENUM('open', 'in_progress', 'resolved') DEFAULT 'open',
    admin_response TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- -------------------------------------------------------
-- Table: notices
-- Admin posts notices visible to all students
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS notices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    posted_by INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES admins(id) ON DELETE CASCADE
);

-- ============================================================
-- SEED DATA: Insert sample rooms
-- ============================================================
INSERT INTO rooms (room_number, floor, capacity, room_type, monthly_fee) VALUES
('101', 1, 1, 'single', 6000.00),
('102', 1, 2, 'double', 4500.00),
('103', 1, 2, 'double', 4500.00),
('201', 2, 2, 'double', 5000.00),
('202', 2, 3, 'triple', 3500.00),
('203', 2, 1, 'single', 6000.00),
('301', 3, 2, 'double', 5500.00),
('302', 3, 3, 'triple', 4000.00);

-- ============================================================
-- SEED DATA: Insert default admin
-- Password: admin123 (bcrypt hashed - will be re-created by app)
-- ============================================================
-- NOTE: The app.py will create the admin on first run automatically.
-- This is just a placeholder.
-- ============================================================
