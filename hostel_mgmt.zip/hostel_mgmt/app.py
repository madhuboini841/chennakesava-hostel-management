# ============================================================
# app.py - Hostel Management System Backend
# Flask + MySQL + bcrypt
# ============================================================

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import mysql.connector
import bcrypt
from datetime import date, datetime
import os

app = Flask(__name__)
app.secret_key = "hostel_secret_key_change_in_production"  # Change this in production!

# ============================================================
# DATABASE CONFIGURATION
# Update these values to match your MySQL setup
# ============================================================
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',         # Your MySQL username
    'password': '',         # Your MySQL password
    'database': 'hostel_db',
    'autocommit': True
}

# ============================================================
# DATABASE HELPER: Get a fresh connection
# ============================================================
def get_db():
    """Returns a MySQL connection. Call this in each route."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except mysql.connector.Error as e:
        print(f"[DB ERROR] {e}")
        return None

# ============================================================
# STARTUP: Create default admin if none exists
# Admin email: admin@hostel.com | Password: admin123
# ============================================================
def create_default_admin():
    conn = get_db()
    if not conn:
        print("[WARN] Could not connect to DB to create admin.")
        return
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id FROM admins LIMIT 1")
    if not cursor.fetchone():
        hashed = bcrypt.hashpw("admin123".encode(), bcrypt.gensalt()).decode()
        cursor.execute(
            "INSERT INTO admins (name, email, password_hash) VALUES (%s, %s, %s)",
            ("Admin", "admin@hostel.com", hashed)
        )
        print("[INFO] Default admin created: admin@hostel.com / admin123")
    cursor.close()
    conn.close()

# ============================================================
# AUTH HELPERS
# ============================================================
def is_logged_in():
    return 'user_id' in session

def is_admin():
    return session.get('role') == 'admin'

def is_student():
    return session.get('role') == 'student'

# ============================================================
# ROUTE: Home - redirect based on login state
# ============================================================
@app.route('/')
def index():
    if is_logged_in():
        if is_admin():
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('student_dashboard'))
    return redirect(url_for('login'))

# ============================================================
# ROUTE: Login (GET = show form, POST = process login)
# ============================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    if is_logged_in():
        return redirect(url_for('index'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        role = request.form.get('role', 'student')  # 'admin' or 'student'

        if not email or not password:
            flash("Email and password are required.", "error")
            return render_template('login.html')

        conn = get_db()
        if not conn:
            flash("Database connection error. Please try again.", "error")
            return render_template('login.html')

        cursor = conn.cursor(dictionary=True)

        if role == 'admin':
            cursor.execute("SELECT * FROM admins WHERE email = %s", (email,))
        else:
            cursor.execute("SELECT * FROM students WHERE email = %s AND status = 'active'", (email,))

        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user and bcrypt.checkpw(password.encode(), user['password_hash'].encode()):
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            session['user_email'] = user['email']
            session['role'] = role
            flash(f"Welcome back, {user['name']}!", "success")
            if role == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('student_dashboard'))
        else:
            flash("Invalid email or password.", "error")

    return render_template('login.html')

# ============================================================
# ROUTE: Logout
# ============================================================
@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for('login'))

# ============================================================
# ROUTE: Register Student (Admin only)
# ============================================================
@app.route('/register', methods=['GET', 'POST'])
def register():
    if not is_admin():
        flash("Admin access required.", "error")
        return redirect(url_for('login'))

    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM rooms WHERE status != 'maintenance' ORDER BY room_number")
    rooms = cursor.fetchall()

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        phone = request.form.get('phone', '').strip()
        roll_number = request.form.get('roll_number', '').strip()
        course = request.form.get('course', '').strip()
        year_of_study = request.form.get('year_of_study', 1)
        room_id = request.form.get('room_id') or None

        if not name or not email or not password:
            flash("Name, email and password are required.", "error")
            cursor.close(); conn.close()
            return render_template('register.html', rooms=rooms)

        # Hash the password
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

        try:
            cursor.execute(
                """INSERT INTO students (name, email, password_hash, phone, roll_number, course, year_of_study, room_id)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                (name, email, hashed, phone, roll_number, course, year_of_study, room_id)
            )
            student_id = cursor.lastrowid

            # Update room occupancy if room assigned
            if room_id:
                cursor.execute(
                    "UPDATE rooms SET current_occupancy = current_occupancy + 1 WHERE id = %s", (room_id,)
                )
                # Update room status if full
                cursor.execute(
                    "UPDATE rooms SET status = IF(current_occupancy >= capacity, 'full', 'available') WHERE id = %s",
                    (room_id,)
                )

            # Create initial fee record for current month
            today = date.today()
            month_name = today.strftime("%B %Y")
            due = today.replace(day=10)  # Due on 10th of the month
            if room_id:
                cursor.execute("SELECT monthly_fee FROM rooms WHERE id = %s", (room_id,))
                room = cursor.fetchone()
                fee_amount = room['monthly_fee'] if room else 5000.00
            else:
                fee_amount = 5000.00

            cursor.execute(
                "INSERT INTO fees (student_id, amount, month, year, due_date) VALUES (%s, %s, %s, %s, %s)",
                (student_id, fee_amount, month_name, today.year, due)
            )

            flash(f"Student '{name}' registered successfully!", "success")
            cursor.close(); conn.close()
            return redirect(url_for('admin_dashboard'))

        except mysql.connector.IntegrityError as e:
            flash("Email or Roll Number already exists.", "error")

    cursor.close()
    conn.close()
    return render_template('register.html', rooms=rooms)

# ============================================================
# ROUTE: Student Dashboard
# ============================================================
@app.route('/student/dashboard')
def student_dashboard():
    if not is_student():
        flash("Please login as a student.", "error")
        return redirect(url_for('login'))

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Get student details with room info
    cursor.execute("""
        SELECT s.*, r.room_number, r.floor, r.room_type, r.monthly_fee
        FROM students s
        LEFT JOIN rooms r ON s.room_id = r.id
        WHERE s.id = %s
    """, (session['user_id'],))
    student = cursor.fetchone()

    # Get latest fee records
    cursor.execute("""
        SELECT * FROM fees WHERE student_id = %s ORDER BY year DESC, id DESC LIMIT 6
    """, (session['user_id'],))
    fees = cursor.fetchall()

    # Get student's complaints
    cursor.execute("""
        SELECT * FROM complaints WHERE student_id = %s ORDER BY submitted_at DESC
    """, (session['user_id'],))
    complaints = cursor.fetchall()

    # Get active notices
    cursor.execute("""
        SELECT n.*, a.name as admin_name FROM notices n
        JOIN admins a ON n.posted_by = a.id
        WHERE n.is_active = TRUE ORDER BY n.created_at DESC LIMIT 10
    """)
    notices = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('student_dashboard.html',
                           student=student,
                           fees=fees,
                           complaints=complaints,
                           notices=notices)

# ============================================================
# ROUTE: Submit Complaint (Student)
# ============================================================
@app.route('/complaints/submit', methods=['POST'])
def submit_complaint():
    if not is_student():
        return jsonify({'error': 'Unauthorized'}), 401

    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    category = request.form.get('category', 'other')

    if not title or not description:
        flash("Title and description are required.", "error")
        return redirect(url_for('student_dashboard'))

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO complaints (student_id, title, description, category) VALUES (%s, %s, %s, %s)",
        (session['user_id'], title, description, category)
    )
    cursor.close()
    conn.close()

    flash("Complaint submitted successfully!", "success")
    return redirect(url_for('student_dashboard'))

# ============================================================
# ROUTE: Admin Dashboard
# ============================================================
@app.route('/admin/dashboard')
def admin_dashboard():
    if not is_admin():
        flash("Admin access required.", "error")
        return redirect(url_for('login'))

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Summary counts
    cursor.execute("SELECT COUNT(*) as total FROM students WHERE status='active'")
    total_students = cursor.fetchone()['total']

    cursor.execute("SELECT COUNT(*) as total FROM rooms WHERE status='available'")
    available_rooms = cursor.fetchone()['total']

    cursor.execute("SELECT COUNT(*) as total FROM complaints WHERE status='open'")
    open_complaints = cursor.fetchone()['total']

    cursor.execute("SELECT COUNT(*) as total FROM fees WHERE status='pending'")
    pending_fees = cursor.fetchone()['total']

    # All students with room info
    cursor.execute("""
        SELECT s.*, r.room_number FROM students s
        LEFT JOIN rooms r ON s.room_id = r.id
        WHERE s.status = 'active'
        ORDER BY s.created_at DESC
    """)
    students = cursor.fetchall()

    # All rooms
    cursor.execute("SELECT * FROM rooms ORDER BY room_number")
    rooms = cursor.fetchall()

    # All complaints with student names
    cursor.execute("""
        SELECT c.*, s.name as student_name, s.roll_number, r.room_number
        FROM complaints c
        JOIN students s ON c.student_id = s.id
        LEFT JOIN rooms r ON s.room_id = r.id
        ORDER BY c.submitted_at DESC
    """)
    complaints = cursor.fetchall()

    # All notices
    cursor.execute("""
        SELECT n.*, a.name as admin_name FROM notices n
        JOIN admins a ON n.posted_by = a.id
        ORDER BY n.created_at DESC
    """)
    notices = cursor.fetchall()

    # Recent fees
    cursor.execute("""
        SELECT f.*, s.name as student_name FROM fees f
        JOIN students s ON f.student_id = s.id
        ORDER BY f.created_at DESC LIMIT 20
    """)
    fees = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('admin_dashboard.html',
                           total_students=total_students,
                           available_rooms=available_rooms,
                           open_complaints=open_complaints,
                           pending_fees=pending_fees,
                           students=students,
                           rooms=rooms,
                           complaints=complaints,
                           notices=notices,
                           fees=fees)

# ============================================================
# ROUTE: Add Notice (Admin)
# ============================================================
@app.route('/notices/add', methods=['POST'])
def add_notice():
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401

    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    priority = request.form.get('priority', 'medium')

    if not title or not content:
        flash("Title and content are required.", "error")
        return redirect(url_for('admin_dashboard'))

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO notices (title, content, priority, posted_by) VALUES (%s, %s, %s, %s)",
        (title, content, priority, session['user_id'])
    )
    cursor.close()
    conn.close()

    flash("Notice posted successfully!", "success")
    return redirect(url_for('admin_dashboard'))

# ============================================================
# ROUTE: Update Complaint Status (Admin)
# ============================================================
@app.route('/complaints/update/<int:complaint_id>', methods=['POST'])
def update_complaint(complaint_id):
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401

    status = request.form.get('status')
    admin_response = request.form.get('admin_response', '').strip()

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE complaints SET status = %s, admin_response = %s WHERE id = %s",
        (status, admin_response, complaint_id)
    )
    cursor.close()
    conn.close()

    flash("Complaint updated successfully!", "success")
    return redirect(url_for('admin_dashboard'))

# ============================================================
# ROUTE: Update Fee Status (Admin)
# ============================================================
@app.route('/fees/update/<int:fee_id>', methods=['POST'])
def update_fee(fee_id):
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401

    status = request.form.get('status')
    payment_date = date.today() if status == 'paid' else None

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE fees SET status = %s, payment_date = %s WHERE id = %s",
        (status, payment_date, fee_id)
    )
    cursor.close()
    conn.close()

    flash("Fee status updated!", "success")
    return redirect(url_for('admin_dashboard'))

# ============================================================
# ROUTE: Assign Room to Student (Admin)
# ============================================================
@app.route('/students/assign-room/<int:student_id>', methods=['POST'])
def assign_room(student_id):
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401

    new_room_id = request.form.get('room_id') or None

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Get current room
    cursor.execute("SELECT room_id FROM students WHERE id = %s", (student_id,))
    student = cursor.fetchone()
    old_room_id = student['room_id'] if student else None

    # Decrease old room occupancy
    if old_room_id:
        cursor.execute(
            "UPDATE rooms SET current_occupancy = GREATEST(0, current_occupancy - 1), status = 'available' WHERE id = %s",
            (old_room_id,)
        )

    # Assign new room
    cursor.execute("UPDATE students SET room_id = %s WHERE id = %s", (new_room_id, student_id))

    # Increase new room occupancy
    if new_room_id:
        cursor.execute(
            "UPDATE rooms SET current_occupancy = current_occupancy + 1 WHERE id = %s", (new_room_id,)
        )
        cursor.execute(
            "UPDATE rooms SET status = IF(current_occupancy >= capacity, 'full', 'available') WHERE id = %s",
            (new_room_id,)
        )

    cursor.close()
    conn.close()

    flash("Room assigned successfully!", "success")
    return redirect(url_for('admin_dashboard'))

# ============================================================
# ROUTE: Delete/Deactivate Student (Admin)
# ============================================================
@app.route('/students/delete/<int:student_id>', methods=['POST'])
def delete_student(student_id):
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401

    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    # Free up the room
    cursor.execute("SELECT room_id FROM students WHERE id = %s", (student_id,))
    student = cursor.fetchone()
    if student and student['room_id']:
        cursor.execute(
            "UPDATE rooms SET current_occupancy = GREATEST(0, current_occupancy - 1), status = 'available' WHERE id = %s",
            (student['room_id'],)
        )

    # Deactivate student (soft delete)
    cursor.execute("UPDATE students SET status = 'inactive', room_id = NULL WHERE id = %s", (student_id,))
    cursor.close()
    conn.close()

    flash("Student removed successfully!", "success")
    return redirect(url_for('admin_dashboard'))

# ============================================================
# ROUTE: Add Room (Admin)
# ============================================================
@app.route('/rooms/add', methods=['POST'])
def add_room():
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401

    room_number = request.form.get('room_number', '').strip()
    floor = request.form.get('floor', 1)
    capacity = request.form.get('capacity', 2)
    room_type = request.form.get('room_type', 'double')
    monthly_fee = request.form.get('monthly_fee', 5000.00)

    if not room_number:
        flash("Room number is required.", "error")
        return redirect(url_for('admin_dashboard'))

    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO rooms (room_number, floor, capacity, room_type, monthly_fee) VALUES (%s, %s, %s, %s, %s)",
            (room_number, floor, capacity, room_type, monthly_fee)
        )
        flash(f"Room {room_number} added successfully!", "success")
    except mysql.connector.IntegrityError:
        flash("Room number already exists.", "error")
    cursor.close()
    conn.close()

    return redirect(url_for('admin_dashboard'))

# ============================================================
# API ROUTES (JSON) - For potential JS fetch usage
# ============================================================
@app.route('/api/students')
def api_students():
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT s.id, s.name, s.email, s.roll_number, s.phone, r.room_number
        FROM students s LEFT JOIN rooms r ON s.room_id = r.id
        WHERE s.status='active'
    """)
    students = cursor.fetchall()
    cursor.close(); conn.close()
    return jsonify(students)

@app.route('/api/rooms')
def api_rooms():
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM rooms ORDER BY room_number")
    rooms = cursor.fetchall()
    cursor.close(); conn.close()
    return jsonify(rooms)

# ============================================================
# RUN THE APP
# ============================================================
if __name__ == '__main__':
    create_default_admin()     # Create admin on first run
    app.run(debug=True, port=5000)
